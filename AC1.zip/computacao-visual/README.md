# Computação Visual — Síntese de Imagens, Processamento de Imagens, Visão Computacional e Visualização Computacional

Trabalho da disciplina de Computação Gráfica (IBMEC) — Rafael

## Objetivo

Demonstrar as diferenças e principais características das quatro áreas da
Computação Visual. Para cada área foi selecionada uma aplicação real,
disponível em um repositório público, executada neste ambiente.

| Área | Entrada | Saída | Pergunta central |
|---|---|---|---|
| **Síntese de Imagens** (Computação Gráfica) | Modelo geométrico + luzes + câmera | Imagem (pixels) | Como gerar uma imagem a partir da descrição de uma cena? |
| **Processamento de Imagens** | Imagem (pixels) | Imagem (pixels) | Como transformar/realçar uma imagem em outra imagem? |
| **Visão Computacional** | Imagem (pixels) | Informação/descrição simbólica | O que existe na imagem e onde? |
| **Visualização Computacional** | Dados (numéricos, científicos, abstratos) | Imagem (pixels) | Como tornar um conjunto de dados visualmente compreensível? |

## Estrutura do repositório

```
computacao-visual/
├── 01-sintese-de-imagens/
│   ├── raytracer.py       # gera resultado.png ao rodar
│   └── resultado.png
├── 02-processamento-de-imagens/
│   ├── processamento.py   # gera resultado.png ao rodar
│   └── resultado.png
├── 03-visao-computacional/
│   ├── visao.py           # gera resultado.png ao rodar
│   └── resultado.png
├── 04-visualizacao-computacional/
│   ├── visualizacao.py    # gera resultado.png ao rodar
│   └── resultado.png
└── requirements.txt
```

Cada script é **autocontido**: todas as imagens de entrada necessárias estão
embutidas em base64 dentro do próprio `.py` (quando aplicável), então basta
instalar as dependências e rodar — não é preciso baixar nada separadamente.

```bash
pip install -r requirements.txt
python3 01-sintese-de-imagens/raytracer.py
python3 02-processamento-de-imagens/processamento.py
python3 03-visao-computacional/visao.py
python3 04-visualizacao-computacional/visualizacao.py
```

---

## 1. Síntese de Imagens (Computação Gráfica)

Parte de um modelo 3D (geometria, materiais, luzes, câmera) e calcula, pixel
a pixel, a imagem final. Técnica usada: **ray tracing** — para cada pixel,
lança-se um raio da câmera; calcula-se a interseção com os objetos da cena
(esfera/plano); aplica-se sombreamento difuso (Lei de Lambert) e um raio de
sombra para determinar se o ponto está na sombra de outro objeto.

- **Repositório:** [`frostdpr/simple-python-raytracer`](https://github.com/frostdpr/simple-python-raytracer) (MIT)
- **Adaptação:** o motor de ray tracing é o mesmo do repositório original; a
  cena (4 esferas coloridas + plano + luz direcional) foi escrita por mim e
  embutida no script para ficar autocontido, no lugar de um arquivo `.txt`
  externo.
- **Aspectos observados:** sombreamento visível no lado das esferas voltado
  para a luz; sombras projetadas no chão alinhadas com a direção da luz;
  projeção em perspectiva; nenhuma imagem de entrada — tudo é calculado a
  partir de números.

![resultado](01-sintese-de-imagens/resultado.png)

## 2. Processamento de Imagens

Parte de uma imagem existente e aplica operações matemáticas sobre os
valores de pixel para produzir outra imagem. Aqui: conversão para escala de
cinza, cálculo de histograma (`cv.calcHist`) e **equalização de histograma**
(`cv.equalizeHist`), técnica clássica de realce de contraste.

- **Repositório:** [`opencv/opencv`](https://github.com/opencv/opencv) — `samples/python/hist.py`
- **Imagem de entrada:** `samples/data/baboon.jpg`, do mesmo repositório
  (embutida em base64 no script).
- **Adaptação:** as funções `hist_curve` e `hist_lines` são as originais do
  OpenCV; só a interface interativa (`cv.imshow`) foi trocada por
  `cv.imwrite`, já que o ambiente não tem GUI.
- **Aspectos observados:** o histograma equalizado (direita) fica muito mais
  espalhado, revelando detalhes que estavam apagados na imagem original —
  mas nenhuma informação nova sobre "o que é" a imagem foi extraída.

![resultado](02-processamento-de-imagens/resultado.png)

## 3. Visão Computacional (Artificial)

Extrai **informação/interpretação** de uma imagem (não outra imagem): onde
estão os objetos, o que eles são. Aqui: detecção de face e olhos com
classificadores em cascata de Haar (algoritmo de Viola-Jones), treinados
previamente em milhares de rostos.

- **Repositório:** [`opencv/opencv`](https://github.com/opencv/opencv) — `samples/python/facedetect.py` + `data/haarcascades/`
- **Imagem de entrada:** `samples/data/lena.jpg`, do mesmo repositório
  (embutida em base64 no script). Os classificadores Haar já vêm junto do
  pacote `opencv-python` (`cv2.data.haarcascades`).
- **Adaptação:** as funções `detect()` e `draw_rects()` são as originais;
  o script passou a rodar sobre uma imagem estática em vez de um vídeo de
  webcam.
- **Aspectos observados:** a saída real do programa é uma lista de
  coordenadas (`Faces detectadas: 1 [[217 201 391 375]]`), desenhada sobre a
  imagem apenas para visualização humana — é uma interpretação simbólica do
  conteúdo, não uma nova imagem.

![resultado](03-visao-computacional/resultado.png)

## 4. Visualização Computacional

Parte de um **conjunto de dados** (não de uma imagem nem de uma cena 3D
fotorrealista) e produz uma representação visual compreensível. Aqui: o
Conjunto de Mandelbrot (dado puramente matemático — contagem de iterações
de `z → z² + c` para cada ponto do plano complexo), visualizado com a
técnica de *shaded relief* (relevo sombreado, comum em visualização de
dados de elevação/geociências), aplicada sobre os dados fractais.

- **Repositório:** [`rougier/scientific-visualization-book`](https://github.com/rougier/scientific-visualization-book) (livro aberto de referência em visualização científica) — `code/showcases/mandelbrot.py`
- **Adaptação:** nenhuma alteração de lógica; script executado como está.
- **Aspectos observados:** não há câmera, luz ou material no sentido da
  Computação Gráfica — a "iluminação" é um artifício puramente visual
  (`LightSource`) aplicado sobre uma matriz de números; não há imagem de
  entrada; a escolha de cores/normalização é uma decisão de design de
  visualização, não uma simulação física.

![resultado](04-visualizacao-computacional/resultado.png)

---

## Comparação final

| Área | Repositório usado | Arquivo executado |
|---|---|---|
| Síntese de Imagens | github.com/frostdpr/simple-python-raytracer | `raytrace.py` (cena própria) |
| Processamento de Imagens | github.com/opencv/opencv | `samples/python/hist.py` |
| Visão Computacional | github.com/opencv/opencv | `samples/python/facedetect.py` + Haar Cascades |
| Visualização Computacional | github.com/rougier/scientific-visualization-book | `code/showcases/mandelbrot.py` |

Apesar de todas trabalharem com "imagens" em algum ponto, o papel da imagem
é diferente em cada área: na Síntese de Imagens ela é o produto final
calculado a partir de um modelo; no Processamento de Imagens ela é ao mesmo
tempo entrada e saída; na Visão Computacional ela é apenas a entrada, sendo
descartada em favor de uma interpretação simbólica; e na Visualização
Computacional ela nem sequer precisa começar como imagem, servindo apenas de
meio para tornar dados abstratos compreensíveis.
