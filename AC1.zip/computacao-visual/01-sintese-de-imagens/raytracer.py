#!/usr/bin/env python3
"""
01 - SINTESE DE IMAGENS (Computacao Grafica)
=============================================

O que este script demonstra
----------------------------
A Sintese de Imagens resolve o problema: dado um modelo 3D da cena
(geometria + materiais + luzes + camera), calcular a cor de cada pixel
de uma imagem final. A tecnica usada aqui e o RAY TRACING: para cada
pixel, lanca-se um raio a partir da camera; calcula-se qual objeto ele
atinge primeiro (interseccao raio-esfera / raio-plano); e a partir do
ponto de interseccao aplica-se sombreamento difuso (Lei de Lambert) e
um raio de sombra (shadow ray) para saber se aquele ponto esta ou nao
na sombra de outro objeto.

Fonte / creditos
-----------------
Motor de ray tracing adaptado do repositorio publico:
    frostdpr/simple-python-raytracer
    https://github.com/frostdpr/simple-python-raytracer  (licenca MIT)

O algoritmo (interseccao, normais, sombreamento, sombras) e o mesmo do
repositorio original. A unica mudanca foi tornar o script autocontido:
em vez de ler a cena de um arquivo .txt externo, a cena (definida por
Rafael, com 4 esferas + 1 plano + 1 luz direcional) esta embutida como
uma string logo abaixo, na mesma linguagem de descricao aceita pelo
programa original.

Como rodar
-----------
    pip install pillow
    python3 raytracer.py

Gera o arquivo resultado.png na mesma pasta.
"""

from PIL import Image

# ---------------------------------------------------------------------------
# Cena (mesma sintaxe de arquivo .txt do raytracer original: png, eye,
# forward, up, color, plane, sphere, sun, bulb, fisheye ...)
# ---------------------------------------------------------------------------
SCENE = """
png 640 480 resultado.png

eye 0 0.4 1.2
forward 0 -0.15 -1
up 0 1 0

color 0.85 0.85 0.9
plane 0 1 0 1

color 0.9 0.15 0.15
sphere -0.7 0 -1.6 0.4

color 0.15 0.55 0.9
sphere 0.25 0.1 -1.3 0.3

color 0.95 0.8 0.1
sphere 1.1 -0.05 -1.9 0.35

color 0.3 0.85 0.4
sphere -0.1 -0.35 -0.9 0.15

color 1 1 1
sun -0.4 0.65 0.5
"""

# ---------------------------------------------------------------------------
# Motor de ray tracing (identico ao repositorio original frostdpr/simple-python-raytracer)
# ---------------------------------------------------------------------------
color, suns, bulbs, to_render = [1, 1, 1], [], [], []
eye, forward, right, up, s = [0, 0, 0], [0, 0, -1], [1, 0, 0], [0, 1, 0], [0]
fisheye = False
w, h = 0, 0


def clamp(num):
    return max(0, min(float(num), 1))


def normalize(vec):
    mag = 0
    for i in vec:
        mag += i ** 2
    mag = mag ** .5
    for i in range(len(vec)):
        vec[i] /= mag


def cross(a, b):
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]


def norm(vec):
    temp = [i ** 2 for i in vec]
    return sum(temp) ** .5


def dot(vec1, vec2):
    return sum([vec1[i] * vec2[i] for i in range(len(vec1))])


def ray(x, y):
    sx = (2 * x - w) / max(w, h)
    sy = (h - 2 * y) / max(w, h)
    if fisheye:
        mag_forward = sum([forward[i] ** 2 for i in range(3)]) ** .5
        sx /= mag_forward
        sy /= mag_forward
        r_2 = sx ** 2 + sy ** 2
        if r_2 ** .5 > 1:
            return None
        else:
            k = (1 - r_2) ** .5
            return [k * forward[i] + sx * right[i] + sy * up[i] for i in range(3)]
    direction = [forward[i] + sx * right[i] + sy * up[i] for i in range(3)]
    return direction


def raytrace(direction, eye_0):
    closest = float('inf')
    col = [0, 0, 0]
    illu = [0, 0, 0]
    t = 0
    closest_obj = None
    normalize(direction)
    for i in to_render:
        if i[0] == 's':
            # verifica se o raio comeca dentro da esfera
            cr = [i[j + 1] - eye_0[j] for j in range(3)]
            r_2 = i[4] ** 2
            inside = norm(cr) ** 2 < r_2
            tc = dot(cr, direction) / norm(direction)
            if not inside and tc < 0:
                continue
            d_2 = norm([eye_0[j] + tc * direction[j] - i[j + 1] for j in range(3)]) ** 2
            if not inside and d_2 > r_2:
                continue
            t_offset = ((r_2 - d_2) ** .5) / norm(direction)
            t = (tc + t_offset) if inside else (tc - t_offset)
        elif i[0] == "p":
            if i[1] != 0:
                temp = [-i[4] / i[1], 0, 0]
            elif i[2] != 0:
                temp = [0, -i[4] / i[2], 0]
            elif i[3] != 0:
                temp = [0, 0, -i[4] / i[3]]
            n = [i[j] for j in range(1, 4)]
            if dot(direction, n) == 0:
                continue
            pr = [temp[j] - eye_0[j] for j in range(3)]
            t = dot(pr, n) / dot(direction, n)
            if t <= 0:
                continue
        if 0 < t < closest:
            col = [i[j] for j in range(5, 8)]
            closest = t
            closest_obj = i
    if closest_obj is not None and (len(suns) != 0 or len(bulbs) != 0):
        point_of_inters = [eye_0[i] + (closest - .000001) * direction[i] for i in range(3)]
        surface_normal = ([point_of_inters[i] - closest_obj[i + 1] for i in range(3)]
                           if closest_obj[0] == 's' else [closest_obj[j] for j in range(1, 4)])
        away_vector = [point_of_inters[i] - eye_0[i] for i in range(3)]
        if dot(surface_normal, away_vector) > 0:
            surface_normal = [-surface_normal[i] for i in range(3)]
        normalize(surface_normal)
        for i in suns:
            light_dir = [i[k] for k in range(3)]
            light_color = [i[k] for k in range(3, 6)]
            if eye_0 == eye:
                g, _ = raytrace(light_dir, point_of_inters)
                if g != float('inf') and g > .01:
                    light_color = [0, 0, 0]  # ponto na sombra
            normal_dot_light = sum([surface_normal[k] * i[k] for k in range(3)])
            if normal_dot_light < 0:
                continue
            for j in range(3):
                illu[j] += col[j] * light_color[j] * normal_dot_light
        for i in bulbs:
            light_dir = [i[k] - point_of_inters[k] for k in range(3)]
            intensity = 1 / sum([light_dir[k] ** 2 for k in range(3)])
            light_color = [i[k] for k in range(3, 6)]
            normalize(light_dir)
            normal_dot_light = sum([surface_normal[k] * light_dir[k] for k in range(3)])
            if normal_dot_light < 0:
                continue
            for j in range(3):
                illu[j] += col[j] * light_color[j] * normal_dot_light * intensity
    return closest, illu


def draw(image, img):
    for i in range(w):
        for j in range(h):
            direction = ray(i, j)
            if direction is None:
                continue
            t, col = raytrace(direction, eye)
            if t != float('inf'):
                col = [int(clamp(col[k]) * 255) for k in range(3)]
                img[i, j] = (col[0], col[1], col[2], 255)


def main():
    global color, suns, bulbs, to_render, eye, forward, right, up, s, fisheye, w, h

    filename = "resultado.png"
    image = None
    img = None

    for line in SCENE.strip("\n").splitlines():
        line = line.strip()
        if not line:
            continue
        words = line.split()
        keyword = words[0]

        if keyword == "png":
            width, height = int(words[1]), int(words[2])
            image = Image.new("RGBA", (width, height), (255, 255, 255, 255))
            img = image.load()
            w, h = width, height
            color, suns, bulbs, to_render = [1, 1, 1], [], [], []
            eye, forward, right, up = [0, 0, 0], [0, 0, -1], [1, 0, 0], [0, 1, 0]
            fisheye = False
            filename = words[3]
        elif keyword == "color":
            color = [float(words[i]) for i in range(1, 4)]
        elif keyword == "sphere":
            temp = ["s"]
            temp.extend([float(words[i]) for i in range(1, 5)])
            temp.extend(color)
            temp.extend(s)
            to_render.append(temp)
        elif keyword == "sun":
            temp = [float(words[i]) for i in range(1, 4)]
            normalize(temp)
            temp.extend(color)
            temp.extend(s)
            suns.append(temp)
        elif keyword == "plane":
            temp = ["p"]
            temp.extend([float(words[i]) for i in range(1, 5)])
            temp.extend(color)
            to_render.append(temp)
        elif keyword == "eye":
            eye = [float(words[i]) for i in range(1, 4)]
        elif keyword == "forward":
            forward = [float(words[i]) for i in range(1, 4)]
            temp = cross(forward, up)
            right = list(temp)
            temp = cross(right, forward)
            up = list(temp)
            normalize(up)
            normalize(right)
        elif keyword == "up":
            temp = cross(forward, cross([float(words[i]) for i in range(1, 4)], forward))
            up = list(temp)
            right = cross(forward, up)
            normalize(up)
            normalize(right)
        elif keyword == "bulb":
            temp = [float(words[i]) for i in range(1, 4)]
            temp.extend(color)
            bulbs.append(temp)
        elif keyword == "fisheye":
            fisheye = True
        elif keyword == "s":
            s = [float(words[1])]

    print("Renderizando...")
    draw(image, img)
    image.save(filename)
    print(f"Imagem salva em: {filename}")


if __name__ == "__main__":
    main()
