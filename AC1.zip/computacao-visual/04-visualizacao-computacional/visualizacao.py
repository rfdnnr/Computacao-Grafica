#!/usr/bin/env python3
"""
04 - VISUALIZACAO COMPUTACIONAL
=================================

O que este script demonstra
------------------------------
A Visualizacao Computacional (ou Cientifica) parte de um conjunto de
DADOS (nao de uma imagem, nem de um modelo 3D fotorrealista) e produz
uma representacao visual que ajuda a compreende-lo. Aqui o "dado" e
puramente matematico: o Conjunto de Mandelbrot, onde para cada ponto
c do plano complexo verificamos quantas iteracoes da formula
z -> z^2 + c sao necessarias ate a sequencia divergir.

Essa matriz de contagens de iteracao e entao visualizada com uma
tecnica chamada "shaded relief" (relevo sombreado): os dados sao
tratados como um mapa de altura e iluminados artificialmente por uma
fonte de luz simulada (matplotlib.colors.LightSource) -- a mesma
tecnica usada para visualizar dados de elevacao/altimetria em
geociencias, aqui reaproveitada para realcar a estrutura fractal.

Fonte / creditos
-----------------
Script executado sem alteracoes de logica a partir do repositorio
publico (livro aberto de referencia em visualizacao cientifica):
    rougier/scientific-visualization-book
    https://github.com/rougier/scientific-visualization-book
    arquivo: code/showcases/mandelbrot.py
    Autor: Nicolas P. Rougier - licenca BSD

Como rodar
-----------
    pip install numpy matplotlib
    python3 visualizacao.py

Gera o arquivo resultado.png na mesma pasta.
"""

import numpy as np
from matplotlib import colors
import matplotlib.pyplot as plt


def mandelbrot_set(xmin, xmax, ymin, ymax, xn, yn, maxiter, horizon=2.0):
    X = np.linspace(xmin, xmax, xn, dtype=np.float32)
    Y = np.linspace(ymin, ymax, yn, dtype=np.float32)
    C = X + Y[:, None] * 1j
    N = np.zeros(C.shape, dtype=int)
    Z = np.zeros(C.shape, np.complex64)
    for n in range(maxiter):
        I = np.less(abs(Z), horizon)
        N[I] = n
        Z[I] = Z[I] ** 2 + C[I]
    N[N == maxiter - 1] = 0
    return Z, N


def main():
    xmin, xmax, xn = -2.75, +1.25, 2000
    ymin, ymax, yn = -1.5, +1.5, 1500
    maxiter = 200
    horizon = 2.0 ** 40
    log_horizon = np.log(np.log(horizon)) / np.log(2)

    print("Calculando o conjunto de Mandelbrot...")
    Z, N = mandelbrot_set(xmin, xmax, ymin, ymax, xn, yn, maxiter, horizon)

    # Recontagem normalizada (suaviza as bandas de cor), conforme:
    # https://linas.org/art-gallery/escape/smooth.html
    with np.errstate(invalid="ignore"):
        M = np.nan_to_num(N + 1 - np.log(np.log(abs(Z))) / np.log(2) + log_horizon)

    width = 10
    height = 10 * yn / xn
    fig = plt.figure(figsize=(width, height), dpi=100)
    ax = fig.add_axes([0, 0, 1, 1], frameon=False, aspect=1)

    # Sombreamento de relevo simulado (shaded relief)
    light = colors.LightSource(azdeg=315, altdeg=10)
    M = light.shade(M, cmap=plt.cm.hot, vert_exag=1.5,
                     norm=colors.PowerNorm(0.3), blend_mode="hsv")

    plt.imshow(M, extent=[xmin, xmax, ymin, ymax], interpolation="bicubic")
    ax.set_xticks([])
    ax.set_yticks([])
    plt.savefig("resultado.png", dpi=200)
    print("Imagem salva em: resultado.png")


if __name__ == "__main__":
    main()
