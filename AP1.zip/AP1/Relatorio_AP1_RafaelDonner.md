# AP1 — Relatório Técnico e Planejamento Visual: “Ibmec em 15 segundos”

**Nome:** Rafael Senra Donner Jorge
**Versão do Software:** Blender 4.5 LTS (4.5.14)
**Nome do Arquivo .blend:** AP1_RafaelDonner.blend

---

## PARTE 1: RELATÓRIO CURTO

### 1. Título da Peça e Conceito Geral
* **Título da Peça:** “Ibmec — Ponto de Partida”
* **Conceito Visual:** A peça parte de um detalhe do próprio logotipo: o ponto amarelo sobre o I. Na cena ele deixa de ser só um elemento gráfico e vira o personagem. É a ideia (criatividade) que nasce no conhecimento, sobe degrau a degrau e só se completa quando chega à marca. A frase-síntese é *“todo futuro começa num ponto”*.

  O espaço 3D foi organizado como uma linha do tempo ao longo do eixo Y, da frente (origem) para o fundo (futuro). No primeiro plano, à esquerda, um **livro aberto** representa a base acadêmica e a **solidez**. Dele sai uma **escada de placas flutuantes**, que representa **construção** e **empreendedorismo**: crescer uma etapa por vez. Ela sobe em diagonal até a letra I. Sobre um pedestal fica a palavra **Ibmec** em relevo. Atrás dela, um **portal hexagonal** enquadra a marca e representa **inovação** e **futuro**, a passagem para o que vem depois. O hexágono foi escolhido por ser a forma de estruturas moleculares, ligada a engenharia e tecnologia.

  Mesmo parado, o quadro se lê como um percurso: livro → escada → marca → portal. A escada funciona como linha-guia que leva o olhar do canto inferior esquerdo até o ponto do I.

### 2. Narrativa e Destaque da Marca Ibmec
* **Apresentação da Marca:** A palavra não foi redesenhada. Importei o **SVG oficial do logotipo** (site ibmec.br) como curvas, com as proporções exatas das letras e do ponto, e usei as duas cores tiradas do próprio arquivo: **azul `#002555`** e **amarelo `#F5AC00`**. As curvas foram extrudadas (6 m de largura, 30 cm de espessura) e convertidas em malha. O ponto do I virou uma esfera de mesmo diâmetro e mesmo centro: de frente é idêntico ao logo, e em 3D pode rolar na AP2.
  No enquadramento, a palavra é o elemento de maior contraste (azul-escuro sobre cinza-claro), fica no centro óptico do quadro e ocupa cerca de 40% da largura. Ela está **paralela ao plano da câmera**, então a projeção perspectiva não distorce as letras, e o portal atrás funciona como moldura dentro da moldura. A câmera fica um pouco acima da palavra para que a linha do horizonte passe atrás do portal e não atravesse as letras. A transformação de cor da cena está em *Standard*, porque o padrão AgX do Blender desbotaria o azul e o amarelo da marca.
* **Ideia de Transformação:** O ponto amarelo começa sozinho, pousado nas páginas do livro. Enquanto ele rola em direção ao fundo, os degraus surgem um a um à sua frente. Quando ele chega ao topo, as letras emergem do pedestal e o portal sobe do chão atrás delas. No fim, o ponto dá um salto e pousa sobre o I, completando o logotipo: a marca só fica inteira quando a ideia chega ao seu lugar.

### 3. Os Três Objetos Autorais
A cena contém exatamente três objetos autorais principais, modelados para estruturar a composição:

1. **Objeto Autoral 1:** `Obj_Livro_Conhecimento`
   * **Função na Cena:** Origem da narrativa e do quadro (primeiro plano, canto inferior esquerdo). Representa a formação acadêmica e a solidez: é de onde a ideia (o ponto) sai.
   * **Modo de Construção:** Construído via primitivas e modificadores. Modelei só a metade direita, com a capa e o bloco de páginas feitos de dois cubos. O bloco de páginas recebeu **9 loop cuts** ao longo de X, e os loops superiores foram elevados por uma curva senoidal a partir da lombada (o mesmo efeito do *Proportional Editing*), o que cria a curvatura das páginas. O modificador **Mirror** em X gera a outra metade e funde a capa na lombada, e o **Bevel** arredonda as arestas. O objeto tem dois materiais: capa e páginas.

2. **Objeto Autoral 2:** `Obj_Escada_Construcao`
   * **Função na Cena:** Caminho e linha-guia do quadro, ligando o livro ao I em diagonal. Representa construção e empreendedorismo, com cada placa sendo uma etapa. As placas flutuam, sem estrutura por baixo, para parecer uma escada “em construção”.
   * **Modo de Construção:** Construído via primitiva e modificadores. É um único degrau (cubo de 1,0 × 0,42 × 0,16 m) com **Inset** na face superior (5 cm de borda, 2 cm de profundidade), que forma um piso rebaixado. Um **Array** com deslocamento constante (0; 0,5; 0,2) m cria 6 degraus, que sobem 1,2 m até o topo do pedestal, e o **Bevel** arredonda as arestas. O Array ficou ativo (não aplicado) de propósito: na AP2 dá para animar a quantidade de degraus de 1 a 6.

3. **Objeto Autoral 3:** `Obj_Portal_Futuro`
   * **Função na Cena:** Fundo e moldura da marca, destino do percurso. Representa inovação e futuridade (a passagem) e fecha a composição.
   * **Modo de Construção:** Modelado do zero a partir de vértices. Um hexágono de 6 vértices (raio 4,4 m) recebeu **Inset** (0,42 m), a face central foi apagada e a moldura ganhou espessura com **Extrude** (0,4 m) e o acabamento com **Bevel**. Depois o portal foi rotacionado 90° em X para ficar em pé, com os lados retos em cima e embaixo. A parte de baixo passa atrás do pedestal e abaixo do chão, então o portal parece nascer de trás da marca.

### 4. Técnicas de Modelagem e Transformações Geométricas
* **Técnicas de Modelagem Utilizadas:**
  * **Curvas:** o SVG entra como curvas Bézier 2D, recebe *Extrude* de curva e é convertido em malha (palavra Ibmec).
  * **Extrusão (Extrude):** espessura da moldura do portal.
  * **Inset:** piso rebaixado dos degraus e a moldura do portal.
  * **Loop Cut:** 9 cortes no bloco de páginas do livro.
  * **Edição proporcional:** curvatura das páginas, com deslocamento gradual dos loops.
  * **Modificadores:** Mirror (livro), Array (escada) e Bevel (letras, livro, escada, portal e pedestal).
  * **Composição de malhas:** a marca é formada pelas letras e pela esfera, agrupadas sob um Empty.
* **Transformações Geométricas:**
  * **Escala:** o logo chega com 3,5 cm de largura e recebe escala uniforme de ×172,5 para ficar com 6 m. A escala é uniforme para não deformar a marca.
  * **Rotação:** +90° em X na palavra, que sai do plano do chão (XY) para o plano vertical (XZ), de frente para a câmera em −Y. O portal recebe a mesma rotação de +90° em X. A câmera tem rotação de 83,3° em X e 3,8° em Z, calculada para mirar o alvo.
  * **Translação:** os elementos estão distribuídos ao longo de Y como linha do tempo: livro em y = −1,55; escada de y = −0,51 a 1,99, subindo 0,2 m em Z a cada 0,5 m em Y; palavra em y = 3,0, sobre o pedestal com topo em z = 1,2; portal em y = 4,6. Em X, o livro e a escada ficam em x = −2,75, alinhados com o I.
  * **Congelamento:** apliquei *Ctrl + A* (rotação e escala) em todos os objetos, que ficaram com rotação zerada e escala 1,0. Mantive a localização de propósito, para que a origem de cada objeto sirva de pivô na animação da AP2: base central da palavra, centro do portal, primeiro degrau e centro do livro.
  * **Hierarquia:** `Ibmec_Letras` e `Ibmec_Ponto` são filhos do Empty `Ibmec_Palavra`. Mover o Empty move a marca inteira, e a posição do ponto é relativa ao pai (espaço local em vez do global).
  * **Projeção:** a câmera é perspectiva, com lente de 32 mm. A palavra fica paralela ao plano da imagem, e a escada gera linhas de fuga que convergem em direção ao I. A captura 05 mostra a mesma cena em **projeção ortográfica** (vista de topo), onde se vê a organização ao longo de Y.

### 5. Organização Técnica da Cena
* **Estrutura de Coleções:** Todos os elementos da cena estão agrupados dentro da coleção principal `AP1_Ibmec_Conceito`, dividida em subcoleções:

  | Subcoleção | Objetos |
  |---|---|
  | `01_Palavra_Ibmec` | `Ibmec_Palavra` (Empty pai), `Ibmec_Letras`, `Ibmec_Ponto` |
  | `02_Objetos_Autorais` | `Obj_Livro_Conhecimento`, `Obj_Escada_Construcao`, `Obj_Portal_Futuro` |
  | `03_Cenario_Auxiliar` | `Aux_Pedestal`, `Aux_Chao` |
  | `04_Camera` | `Cam_Principal_AP1`, `Cam_Alvo` |

* **Configuração da Câmera:** A câmera principal (`Cam_Principal_AP1`) é perspectiva, com lente de 32 mm e saída em 1920 × 1080. Ela fica em (0,9; −11; 3,8), um pouco acima e à direita da palavra, com uma restrição *Track To* apontando para o Empty `Cam_Alvo`. Na AP2 basta animar a posição da câmera e do alvo. O arquivo abre na vista da câmera em *Solid mode*, com as cores dos materiais.
* **Linha do Tempo Planejada:** Duração configurada para **360 frames** a **24 fps** (frames 1 a 360, totalizando 15 segundos).

### 6. Plano Resumido para a AP2 (Evolução da Cena)
Para a segunda etapa da avaliação (AP2), estão planejadas as seguintes evoluções:
* **Animação de Objetos e Câmera:** O ponto rola do livro e sobe a escada, com keyframes de localização e de rotação (para girar enquanto rola) e um pequeno quique em cada degrau. A quantidade do Array é animada de 1 a 6, para os degraus surgirem à frente do ponto. As letras sobem do pedestal com *ease-out*, separadas por letra para subirem em sequência. O portal sobe do chão e gira 60°; como o hexágono tem simetria de 60°, o giro termina encaixado. A câmera faz um *dolly* e um arco, animando a câmera e o `Cam_Alvo`, e trava no enquadramento principal.
* **Iluminação e Materiais:** Fundo claro e neutro, com luz principal suave e *rim light* para separar as letras do portal. As letras terão azul `#002555` acetinado, e o ponto terá amarelo `#F5AC00` com emissão sutil, que acende quando ele pousa no I. O portal terá metal escovado com um filete emissivo, a escada terá acrílico fosco, e o livro terá papel nas páginas e tecido na capa.
* **Renderização Final:** Eevee, pela velocidade em 360 frames a 1920 × 1080, exportando MP4 (H.264) pelo FFmpeg. As cores da marca serão conferidas no *color management* antes do render final.

---

## PARTE 2: STORYBOARD (PLANEJAMENTO AUDIOVISUAL DE 15 SEGUNDOS)

A storyboard divide a animação planejada para a AP2 em **três momentos principais**, cobrindo os 360 frames a 24 fps. As imagens são quadros da própria cena, com as poses de cada momento.

### QUADRO 1: INÍCIO E REVELAÇÃO (0s a 3s | Frames 1 a 72)

![Quadro 1](imagens/storyboard_q1_inicio.png)

* **Ação/Movimento:** A câmera começa baixa e próxima do livro e se afasta lentamente. O ponto amarelo aparece sobre as páginas (a escala vai de 0 a 1 com um leve quique) e começa a rolar pela lombada em direção ao primeiro degrau.
* **Elementos em Destaque:** `Obj_Livro_Conhecimento`, `Ibmec_Ponto` e o primeiro degrau da `Obj_Escada_Construcao`. As letras e o portal ainda estão escondidos, abaixo do pedestal e do chão.
* **Foco do Áudio/Visual:** Estabelecer a origem: do conhecimento nasce a ideia. O quadro é limpo, quase vazio, com um som suave de “clique” quando o ponto aparece.

### QUADRO 2: TRANSFORMAÇÃO E CLÍMAX (3s a 10s | Frames 73 a 240)

![Quadro 2](imagens/storyboard_q2_transformacao.png)

* **Ação/Movimento:** O ponto sobe a escada degrau a degrau, e cada degrau surge logo à frente dele (Array de 1 a 6). A câmera sobe em arco pela esquerda, acompanhando a diagonal. As letras começam a emergir do pedestal, e o portal sobe do chão atrás delas.
* **Elementos em Destaque:** A escada completa, o ponto no meio do caminho, as letras a meia altura e o portal subindo.
* **Foco do Áudio/Visual:** Construção e crescimento. O ritmo acelera a cada degrau, com uma batida por degrau, e este é o trecho de maior movimento da peça.

### QUADRO 3: ENCERRAMENTO E FIXAÇÃO DA MARCA (10s a 15s | Frames 241 a 360)

![Quadro 3](imagens/storyboard_q3_encerramento.png)

* **Ação/Movimento:** No topo, o ponto salta e pousa sobre o I, por volta do frame 264 (11 s), completando o logotipo. O portal termina de subir e gira 60° até assentar. A câmera desacelera e trava no enquadramento principal (`Cam_Principal_AP1`), e a imagem fica parada nos últimos ~3 s.
* **Elementos em Destaque:** A palavra **Ibmec** completa e legível, o portal enquadrando a marca, e o livro e a escada como o caminho percorrido.
* **Foco do Áudio/Visual:** Fixação da marca: *“todo futuro começa num ponto”*. O final é estático e limpo, com o som resolvendo junto com a última batida.

---

## Anexo — Capturas da Cena (Solid mode, render Workbench)

| Captura | Arquivo |
|---|---|
| Enquadramento principal (câmera) | `imagens/AP1_RafaelDonner_01_enquadramento_principal.png` |
| Objeto 1 — Livro e palavra Ibmec | `imagens/AP1_RafaelDonner_02_livro_conhecimento.png` |
| Objeto 2 — Escada e palavra Ibmec | `imagens/AP1_RafaelDonner_03_escada_construcao.png` |
| Objeto 3 — Portal e palavra Ibmec | `imagens/AP1_RafaelDonner_04_portal_futuro.png` |
| Planta em projeção ortográfica | `imagens/AP1_RafaelDonner_05_planta_ortografica.png` |

![Livro](imagens/AP1_RafaelDonner_02_livro_conhecimento.png)
![Escada](imagens/AP1_RafaelDonner_03_escada_construcao.png)
![Portal](imagens/AP1_RafaelDonner_04_portal_futuro.png)
![Planta ortográfica](imagens/AP1_RafaelDonner_05_planta_ortografica.png)
