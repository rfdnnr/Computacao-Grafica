# AP1 - Cena-conceito "Ponto de Partida" (Ibmec em 15 segundos)
# Rafael Donner - Computacao Grafica (IBMEC)
#
# Monta a cena da AP1: a palavra Ibmec a partir do SVG oficial da marca, os tres
# objetos autorais (livro, escada, portal), o cenario auxiliar, a camera principal
# e a timeline de 360 frames a 24 fps. Salva AP1_RafaelDonner.blend na mesma pasta.
#
# Feito no Blender 4.5 LTS. Rodar: blender -b --factory-startup --python AP1_RafaelDonner.py
# (o arquivo ibmec_logo.svg precisa estar na mesma pasta do script)

import bpy
import addon_utils
import bmesh
import math
import os
from mathutils import Vector, Matrix

PASTA = os.path.dirname(os.path.abspath(__file__))

# Layout no eixo Y: a narrativa anda de frente (livro) para tras (portal)
Y_LIVRO = -1.55
Y_PALAVRA = 3.0
Y_PORTAL = 4.6
Z_TOPO_PEDESTAL = 1.2
X_COLUNA_I = -2.75  # a escada sobe alinhada com a letra I

cena = bpy.context.scene


# ---------------------------------------------------------------- utilitarios

def hex_para_linear(h):
    h = h.lstrip('#')
    srgb = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return tuple(c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4 for c in srgb) + (1.0,)


def material(nome, hexcor, rugosidade=0.5):
    mat = bpy.data.materials.new(nome)
    cor = hex_para_linear(hexcor)
    mat.diffuse_color = cor  # cor exibida no viewport (Solid mode)
    if mat.node_tree is None:
        mat.use_nodes = True
    bsdf = next(n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED')
    bsdf.inputs['Base Color'].default_value = cor
    bsdf.inputs['Roughness'].default_value = rugosidade
    return mat


def objeto_de_bmesh(nome, bm, colecao, local):
    malha = bpy.data.meshes.new(nome)
    bm.to_mesh(malha)
    bm.free()
    obj = bpy.data.objects.new(nome, malha)
    colecao.objects.link(obj)
    obj.location = local
    return obj


def mover_para(obj, colecao):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    colecao.objects.link(obj)


def ativar(obj):
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj


def congelar(obj, local=False, rotacao=True):
    # Ctrl+A: aplica escala e rotacao (e a localizacao, se pedido) na geometria
    ativar(obj)
    bpy.ops.object.transform_apply(location=local, rotation=rotacao, scale=True)


def bevel(obj, largura, segmentos=2):
    mod = obj.modifiers.new('Bevel', 'BEVEL')
    mod.width = largura
    mod.segments = segmentos
    mod.limit_method = 'ANGLE'
    return mod


def verts_de(geom):
    return [e for e in geom if isinstance(e, bmesh.types.BMVert)]


# ---------------------------------------------------------------- cena limpa

for obj in list(bpy.data.objects):
    bpy.data.objects.remove(obj, do_unlink=True)
for col in list(bpy.data.collections):
    bpy.data.collections.remove(col)

cena.render.fps = 24
cena.render.fps_base = 1.0
cena.frame_start = 1
cena.frame_end = 360  # 15 s x 24 fps
cena.frame_current = 1
cena.render.resolution_x = 1920
cena.render.resolution_y = 1080

# Colecao principal e subcolecoes
principal = bpy.data.collections.new('AP1_Ibmec_Conceito')
cena.collection.children.link(principal)
col_palavra = bpy.data.collections.new('01_Palavra_Ibmec')
col_autorais = bpy.data.collections.new('02_Objetos_Autorais')
col_cenario = bpy.data.collections.new('03_Cenario_Auxiliar')
col_camera = bpy.data.collections.new('04_Camera')
for c in (col_palavra, col_autorais, col_cenario, col_camera):
    principal.children.link(c)

# Materiais: azul e amarelo tirados do SVG oficial; o resto em neutros
mat_azul = material('MAT_Ibmec_Azul', '#002555', 0.35)
mat_amarelo = material('MAT_Ibmec_Amarelo', '#F5AC00', 0.3)
mat_capa = material('MAT_Livro_Capa', '#6E7A8E')
mat_paginas = material('MAT_Livro_Paginas', '#F7F4EC', 0.8)
mat_escada = material('MAT_Escada', '#D5DAE3')
mat_portal = material('MAT_Portal', '#AEB7C6', 0.3)
mat_pedestal = material('MAT_Pedestal', '#E1E4EA')
mat_chao = material('MAT_Chao', '#EEF0F4', 0.9)


# ---------------------------------------------------------------- palavra Ibmec

# Importa o logo oficial como curvas (letras + ponto amarelo do I)
addon_utils.enable('io_curve_svg', default_set=True)
antes = set(bpy.data.objects)
bpy.ops.import_curve.svg(filepath=os.path.join(PASTA, 'ibmec_logo.svg'))
importados = [o for o in bpy.data.objects if o not in antes]
col_svg = importados[0].users_collection[0]
letras = max(importados, key=lambda o: o.dimensions.x)
ponto_svg = min(importados, key=lambda o: o.dimensions.x)
letras.name = 'Ibmec_Letras'
ponto_svg.name = 'SVG_Ponto'

# Escala uniforme: a palavra passa a ter 6 m de largura
k = 6.0 / letras.dimensions.x
for obj in (letras, ponto_svg):
    mover_para(obj, col_palavra)
    obj.scale = (k, k, k)
    congelar(obj, rotacao=False)  # curva 2D so aceita aplicar escala

# Aplicar a escala tambem multiplica o raio dos pontos da curva (que escala a extrusao)
for spline in letras.data.splines:
    for p in spline.bezier_points:
        p.radius = 1.0

# Curva 2D -> relevo: extrusao da curva e conversao para malha
letras.data.dimensions = '2D'
letras.data.fill_mode = 'BOTH'
letras.data.extrude = 0.15  # 30 cm de espessura
letras.data.resolution_u = 16
ponto_svg.data.dimensions = '2D'
for obj in (letras, ponto_svg):
    ativar(obj)
    bpy.ops.object.convert(target='MESH')
letras = bpy.data.objects['Ibmec_Letras']
ponto_svg = bpy.data.objects['SVG_Ponto']

# Rotacao de 90 graus em X: a palavra sai do chao e fica de pe, de frente para -Y
for obj in (letras, ponto_svg):
    obj.rotation_euler = (math.radians(90), 0, 0)
    congelar(obj, local=True)

# Origem da palavra na base central das letras; tudo vai para cima do pedestal
co = [v.co for v in letras.data.vertices]
base = Vector(((min(c.x for c in co) + max(c.x for c in co)) / 2,
               (min(c.y for c in co) + max(c.y for c in co)) / 2,
               min(c.z for c in co)))
letras.data.transform(Matrix.Translation(-base))
co_ponto = [v.co for v in ponto_svg.data.vertices]
minimo = Vector([min(c[i] for c in co_ponto) for i in range(3)])
maximo = Vector([max(c[i] for c in co_ponto) for i in range(3)])
centro_ponto = (minimo + maximo) / 2 - base
raio_ponto = (maximo.x - minimo.x) / 2
altura_logo = centro_ponto.z + raio_ponto

bpy.data.objects.remove(ponto_svg, do_unlink=True)
bpy.data.collections.remove(col_svg)

letras.data.materials.clear()
letras.data.materials.append(mat_azul)
bevel(letras, 0.008)

# Ponto do I como esfera: de frente e identico ao logo, em 3D pode rolar na AP2
bm = bmesh.new()
bmesh.ops.create_uvsphere(bm, u_segments=48, v_segments=24, radius=raio_ponto)
for f in bm.faces:
    f.smooth = True
ponto = objeto_de_bmesh('Ibmec_Ponto', bm, col_palavra, (0, 0, 0))
ponto.data.materials.append(mat_amarelo)

# Empty pai: move a marca inteira como uma unidade
palavra = bpy.data.objects.new('Ibmec_Palavra', None)
palavra.empty_display_type = 'PLAIN_AXES'
palavra.empty_display_size = 0.5
col_palavra.objects.link(palavra)
palavra.location = (0, Y_PALAVRA, Z_TOPO_PEDESTAL)
letras.parent = palavra
letras.location = (0, 0, 0)
ponto.parent = palavra
ponto.location = centro_ponto

Z_CENTRO_LOGO = Z_TOPO_PEDESTAL + altura_logo / 2


# ---------------------------------------------------------------- cenario auxiliar

bm = bmesh.new()
bmesh.ops.create_grid(bm, x_segments=1, y_segments=1, size=200)  # chao grande: horizonte fica acima da palavra
chao = objeto_de_bmesh('Aux_Chao', bm, col_cenario, (0, 0, 0))
chao.data.materials.append(mat_chao)

bm = bmesh.new()
bmesh.ops.create_cube(bm, size=1.0)
bmesh.ops.scale(bm, vec=(7.0, 1.6, Z_TOPO_PEDESTAL), verts=bm.verts)
bmesh.ops.translate(bm, vec=(0, 0, Z_TOPO_PEDESTAL / 2), verts=bm.verts)
pedestal = objeto_de_bmesh('Aux_Pedestal', bm, col_cenario, (0, Y_PALAVRA, 0))
pedestal.data.materials.append(mat_pedestal)
bevel(pedestal, 0.03, 3)


# ---------------------------------------------------------------- objeto autoral 1: livro

# Modelado pela metade (capa + bloco de paginas) e espelhado com Mirror em X
bm = bmesh.new()
capa = bmesh.ops.create_cube(bm, size=1.0)['verts']
bmesh.ops.scale(bm, vec=(1.1, 1.44, 0.05), verts=capa)
bmesh.ops.translate(bm, vec=(0.55, 0, 0.025), verts=capa)

paginas = bmesh.ops.create_cube(bm, size=1.0)['verts']
bmesh.ops.scale(bm, vec=(1.03, 1.36, 0.14), verts=paginas)
bmesh.ops.translate(bm, vec=(0.02 + 0.515, 0, 0.05 + 0.07), verts=paginas)
faces_paginas = {f for v in paginas for f in v.link_faces}
for f in faces_paginas:
    f.material_index = 1

# Loop cuts: 9 cortes ao longo de X no bloco de paginas
arestas_x = [e for e in {e for f in faces_paginas for e in f.edges}
             if abs(e.verts[0].co.x - e.verts[1].co.x) > 0.5]
bmesh.ops.subdivide_edges(bm, edges=arestas_x, cuts=9, use_grid_fill=True)

# Curvatura das paginas: cada loop sobe com uma queda suave a partir da lombada
# (mesmo efeito do Proportional Editing, feito por funcao)
for v in bm.verts:
    if v.co.x >= 0.019 and v.co.z > 0.1:
        t = (v.co.x - 0.02) / 1.03
        v.co.z += 0.12 * math.sin(math.pi * 0.75 * t)

livro = objeto_de_bmesh('Obj_Livro_Conhecimento', bm, col_autorais, (X_COLUNA_I, Y_LIVRO, 0))
livro.data.materials.append(mat_capa)
livro.data.materials.append(mat_paginas)
espelho = livro.modifiers.new('Mirror', 'MIRROR')
espelho.use_axis[0] = True
espelho.use_clip = True
espelho.use_mirror_merge = True
bevel(livro, 0.01)


# ---------------------------------------------------------------- objeto autoral 2: escada

# Um degrau (placa com piso rebaixado por Inset) repetido pelo Array modifier
bm = bmesh.new()
bmesh.ops.create_cube(bm, size=1.0)
bmesh.ops.scale(bm, vec=(1.0, 0.42, 0.16), verts=bm.verts)
bm.normal_update()
piso = [f for f in bm.faces if f.normal.z > 0.9]
bmesh.ops.inset_region(bm, faces=piso, thickness=0.05, depth=-0.02)

# degrau 1 comeca logo atras do livro; o 6o encosta no pedestal com o topo em z = 1,2
escada = objeto_de_bmesh('Obj_Escada_Construcao', bm, col_autorais, (X_COLUNA_I, -0.51, 0.12))
escada.data.materials.append(mat_escada)
array = escada.modifiers.new('Array_Degraus', 'ARRAY')
array.count = 6
array.use_relative_offset = False
array.use_constant_offset = True
array.constant_offset_displace = (0, 0.5, 0.2)  # passo: 50 cm para tras, 20 cm para cima
bevel(escada, 0.015)


# ---------------------------------------------------------------- objeto autoral 3: portal

# Hexagono (6 vertices) -> Inset -> apaga a face central -> Extrude da moldura
R_PORTAL = 4.4
bm = bmesh.new()
hexagono = bm.faces.new([bm.verts.new((R_PORTAL * math.cos(math.radians(a)),
                                       R_PORTAL * math.sin(math.radians(a)), 0))
                         for a in range(0, 360, 60)])
bm.normal_update()
bmesh.ops.inset_individual(bm, faces=[hexagono], thickness=0.42)
bmesh.ops.delete(bm, geom=[hexagono], context='FACES_ONLY')
moldura = bmesh.ops.extrude_face_region(bm, geom=list(bm.faces))
bmesh.ops.translate(bm, vec=(0, 0, 0.4), verts=verts_de(moldura['geom']))
bmesh.ops.translate(bm, vec=(0, 0, -0.2), verts=bm.verts)  # centraliza a espessura
bmesh.ops.recalc_face_normals(bm, faces=bm.faces)

portal = objeto_de_bmesh('Obj_Portal_Futuro', bm, col_autorais, (0, Y_PORTAL, Z_CENTRO_LOGO))
portal.data.materials.append(mat_portal)
# Rotacao de 90 graus em X: o hexagono fica de pe, com lados retos em cima e embaixo
portal.rotation_euler = (math.radians(90), 0, 0)
congelar(portal)
bevel(portal, 0.04, 3)


# ---------------------------------------------------------------- camera principal

alvo = bpy.data.objects.new('Cam_Alvo', None)
alvo.empty_display_type = 'SPHERE'
alvo.empty_display_size = 0.25
col_camera.objects.link(alvo)
alvo.location = (0, Y_PALAVRA - 0.5, Z_CENTRO_LOGO + 0.05)

dados_cam = bpy.data.cameras.new('Cam_Principal_AP1')
dados_cam.lens = 32
camera = bpy.data.objects.new('Cam_Principal_AP1', dados_cam)
col_camera.objects.link(camera)
# um pouco acima da palavra: o horizonte sai de tras das letras e o piso da escada aparece
camera.location = (0.9, -11.0, 3.8)
# rotacao calculada olhando para o alvo; o Track To mantem isso quando a camera andar na AP2
direcao = alvo.location - camera.location
camera.rotation_euler = direcao.to_track_quat('-Z', 'Y').to_euler()
mira = camera.constraints.new('TRACK_TO')
mira.target = alvo
mira.track_axis = 'TRACK_NEGATIVE_Z'
mira.up_axis = 'UP_Y'
cena.camera = camera


# ---------------------------------------------------------------- visualizacao (Solid)

try:
    cena.render.engine = 'BLENDER_WORKBENCH'
except TypeError as erro:
    print(erro)
sombreamento = cena.display.shading
sombreamento.light = 'STUDIO'
sombreamento.studio_light = 'paint.sl'
sombreamento.color_type = 'MATERIAL'
sombreamento.show_shadows = True
sombreamento.shadow_intensity = 0.3
sombreamento.show_cavity = True
sombreamento.cavity_type = 'WORLD'
cena.display.light_direction = (0.45, -0.55, 0.7)
cena.display.render_aa = '16'
mundo = cena.world or bpy.data.worlds.new('World')
cena.world = mundo
mundo.color = hex_para_linear('#EEF0F4')[:3]
cena.view_settings.view_transform = 'Standard'  # AgX desbota o azul e o amarelo da marca

# Viewport abre na vista da camera, em Solid com as cores dos materiais
for tela in bpy.data.screens:
    for area in tela.areas:
        if area.type == 'VIEW_3D':
            for espaco in area.spaces:
                if espaco.type == 'VIEW_3D':
                    espaco.shading.type = 'SOLID'
                    espaco.shading.color_type = 'MATERIAL'
                    espaco.shading.light = 'STUDIO'
                    espaco.shading.studio_light = 'paint.sl'
                    espaco.shading.show_shadows = True
                    espaco.shading.show_cavity = True
                    espaco.region_3d.view_perspective = 'CAMERA'

bpy.ops.object.select_all(action='DESELECT')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(PASTA, 'AP1_RafaelDonner.blend'))
print('AP1 salvo. Centro do logo em z =', round(Z_CENTRO_LOGO, 3))
